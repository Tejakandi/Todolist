import React, { useState, useEffect } from 'react';
import './App.css';
import Login from './assets/Login';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Sidebar from './assets/Sidebar';
import Navbar from './assets/Navbar';
import Todo from './assets/Todo';
import Important from './assets/Important';
import Planned from './assets/Planned';
import Assigned from './assets/Assigned';

const App = () => {

  const [notificationCount, setNotificationCount] = useState(0);
  const [isDarkmode, setDarkMode] = useState(false);
  const [userName, setUserName] = useState(''); // State for storing user name
  const updateNotificationCount = (count) => {
    setNotificationCount(count);
  };


  const toggleTheme = () => {
    setDarkMode(!isDarkmode);
  };

  useEffect(() => {
    // Check if user is logged in by verifying if the username is stored in localStorage
    const storedUserName = localStorage.getItem('userName');
    if (storedUserName) {
      setUserName(storedUserName);
    }

    if (isDarkmode) {
      document.body.classList.add('darktheme');
      document.body.classList.remove('light-mode');
    } else {
      document.body.classList.add('light-mode');
      document.body.classList.remove('darktheme');
    }
  }, [isDarkmode]);

  return (
    <Router>
      <div className={`dashboard ${isDarkmode ? 'darktheme' : 'light-mode'}`}>
        <Routes>
          {/* Login route */}
          <Route
            path="/login"
            element={<Login setUserName={setUserName} />}
          />
          
          {/* Protected routes (only accessible if the user is logged in) */}
          <Route
            path="/*"
            element={
              userName ? (
                <>
                  <Sidebar toggleTheme={toggleTheme} isDarkmode={isDarkmode} />
                  <div className="app-container">
                    <Navbar userName={userName} />
                    <Routes>
                      <Route path="/" element={<Todo />} />
                      <Route path="/Important" element={<Important />} />
                      <Route path="/Planned" element={<Planned />} />
                      <Route path="/Assigned" element={<Assigned />} />
                    </Routes>
                  </div>
                </>
              ) : (
                // Redirect to login page if not logged in
                <Navigate to="/login" />
              )
            }
          />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
