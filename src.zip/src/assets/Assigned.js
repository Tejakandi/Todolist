import React from 'react'
import {Link} from 'react-router-dom';
const Assigned = () => {
  return (
    <div className='Assign'>Assigned Tasks</div>
  )
}

export default Assigned