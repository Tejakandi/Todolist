import React from 'react'
import {Link} from 'react-router-dom';
const important = ({toggleTheme, isDarkmode}) => {
  return (
    <div>
        <h1 className='Important'>Important tasks</h1>
    </div>
  )
}

export default important