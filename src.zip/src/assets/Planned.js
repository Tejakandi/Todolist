import React from 'react'

const Planned = () => {
  return (
    <div className='today-task'>Planned</div>
  )
}

export default Planned