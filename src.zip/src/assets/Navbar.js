import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FaClipboardList, FaCalendar, FaStar, FaHourglassEnd, FaUser, FaPlus } from 'react-icons/fa';
import downloadImage from '../images/download.jpeg';
import circleImage from '../images/circle.png';
import { FaCircleInfo } from 'react-icons/fa6';

const Navbar = ({ toggleTheme, isDarkmode }) => {
  const userName = localStorage.getItem('userName');
  const [todayTasks, setTodayTasks] = useState([]);
  const [completedTasks, setCompletedTasks] = useState([]);

  // Function to update today's tasks and completed tasks
  const updateTasks = () => {
    const savedToDoList = JSON.parse(localStorage.getItem('todolist')) || [];
    const today = new Date().toISOString().split('T')[0];  // Get today's date
    const filteredTasks = savedToDoList.filter((task) => task.date === today);
    const completed = filteredTasks.filter((task) => task.completed);
    setTodayTasks(filteredTasks);  // Update state with today's tasks
    setCompletedTasks(completed);  // Update state with completed tasks
  };

  // UseEffect to call updateTasks when the component mounts
  useEffect(() => {
    updateTasks();

    // Listen for changes to localStorage and update tasks when changes occur
    const handleStorageChange = () => updateTasks();
    window.addEventListener('storage', handleStorageChange);

    // Clean up the event listener when the component unmounts
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);  // Empty dependency array ensures it runs only once on mount

  return (
    <div className="sidebar">
      <img src={downloadImage} alt="Download" className="image" />
      <h1>Hey, {userName || 'Guest'}</h1>

      <div className="tasks">
        <Link to="/" className="task-item">
          <span className="icon"><FaClipboardList /></span>
          <span className="text">All Tasks</span>
        </Link>

        <Link to="/Important" className="task-item">
          <span className="icon"><FaStar /></span>
          <span className="text">Important</span>
        </Link>

        <Link to="/Planned" className="task-item">
          <span className="icon"><FaHourglassEnd /></span>
          <span className="text">Planned</span>
        </Link>

        <Link to="/Assigned" className="task-item">
          <span className="icon"><FaUser /></span>
          <span className="text">Assigned to me</span>
        </Link>
      </div>

      <div className="list">
        <FaPlus />
        <h6>Add List</h6>
      </div>

      <div className="today">
        <h6>Today Tasks</h6>
        <FaCircleInfo className="circle" />
        <p>{todayTasks.length} Tasks </p>
      </div>

      <div className="done">
        <img src={circleImage} alt="Figma" className="pie" />
        <div className="round">
          <span className="pen">.</span>
          <span className="ing">Pending</span>
          <span className="do">.</span>
          <span className="ing">Done</span>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
