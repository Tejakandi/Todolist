import React, { useState, useEffect } from 'react';
import { FaBell, FaCalendar, FaStar } from 'react-icons/fa';
import { FaShuffle, FaSquare, FaXmark } from 'react-icons/fa6';

const Todo = () => {
  const [todolist, settodolist] = useState([]);

  // Load the saved ToDo list from localStorage
  useEffect(() => {
    const savedToDoList = localStorage.getItem('todolist');
    if (savedToDoList) {
      settodolist(JSON.parse(savedToDoList));
    }
  }, []);

  // Save the ToDo list to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('todolist', JSON.stringify(todolist));
    // Dispatch custom event to notify other components about the update
    window.dispatchEvent(new Event('storage'));
  }, [todolist]);

  const saveToDoList = (event) => {
    event.preventDefault();

    const toname = event.target.toname.value.trim();
    const todate = event.target.todate.value;

    if (!toname || !todate) {
      alert('Both Task Name and Date are required!');
      return;
    }

    const newTask = { name: toname, date: todate, completed: false };

    if (!todolist.some((task) => task.name === toname)) {
      settodolist([...todolist, newTask]);
    } else {
      alert('Task Name Already Exists!');
    }

    // Clear the input fields after submission
    event.target.toname.value = '';
    event.target.todate.value = '';
  };

  const markAsCompleted = (index) => {
    const updatedToDoList = [...todolist];
    updatedToDoList[index].completed = !updatedToDoList[index].completed;
    settodolist(updatedToDoList);
  };

  const list = todolist.map((task, index) => (
    <TodolistItems
      task={task}
      key={index}
      indexnumber={index}
      todolist={todolist}
      settodolist={settodolist}
      markAsCompleted={markAsCompleted}
    />
  ));

  const completedTasks = todolist.filter((task) => task.completed);

  return (
    <div className="Todolist">
      <h1 className="doto">
        ToDo
        <hr />
      </h1>
      <div className="forms">
        <form onSubmit={saveToDoList}>
          <input type="text" placeholder="Add A Task" name="toname" />
          <input type="date" name="todate" />
          <button type="submit">Add Task</button>
        </form>
        <div className="clicks">
          <div className="notification-icon">
            <FaBell />
          </div>
          <FaShuffle />
          <FaCalendar />
        </div>
      </div>
      <div className="outerdiv">
        <ul>{list}</ul>
      </div>
      <div className="completed-tasks">
        <h2>Completed Tasks</h2>
        <ul>
          {completedTasks.length > 0 ? (
            completedTasks.map((task, index) => (
              <li key={index} className="completed">
                {task.name} - {task.date}
              </li>
            ))
          ) : (
            <li>No tasks completed yet.</li>
          )}
        </ul>
      </div>
    </div>
  );
};

export default Todo;

function TodolistItems({ task, indexnumber, todolist, settodolist, markAsCompleted }) {
  const deleteRow = () => {
    const finalData = todolist.filter((_, i) => i !== indexnumber);
    settodolist(finalData);
  };

  return (
    <li className={task.completed ? 'completed' : ''}>
      <span
        onClick={() => markAsCompleted(indexnumber)}
        className="task-square"
      >
        <FaSquare />
      </span>
      {task.name} - {task.date}
      <span onClick={deleteRow}>
        <FaXmark  className='xmark'/>
      </span>
    </li>
  );
}
