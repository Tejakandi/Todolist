import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [userName, setUserName] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    if (userName.trim()) {
      localStorage.setItem('userName', userName); // Save user name in localStorage
      navigate('/'); 
    } else {
      alert('Please enter a name to continue!');
    }
  };

  return (
    <div className='login'>
      <h1>WELCOME</h1>
      <input
        type="text"
        placeholder="Enter your name"
        value={userName}
        onChange={(e) => setUserName(e.target.value)}
      />
      <button onClick={handleLogin}>Login</button>
    </div>
  );
};

export default Login;
