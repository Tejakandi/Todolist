import React from 'react';
import { FaBars, FaRegMoon, FaSearch, FaThLarge } from 'react-icons/fa';

const Sidebar = ({ toggleTheme, isDarkmode }) => {
  return (
    <div className="navbar">
      <FaBars className="bars" />
      <h1>DoIt</h1>
      <div className="icons">
        <FaSearch />
        <FaThLarge />
        <FaRegMoon onClick={toggleTheme} style={{ cursor: 'pointer' }} />
      </div>
    </div>
  );
};

export default Sidebar;
